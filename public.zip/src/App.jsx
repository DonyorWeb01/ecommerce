import React, { useEffect, useState } from "react";
import "./App.scss";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "./components/navbar/Navbar";
import Footer from "./components/footer/Footer";
import Home from "./pages/home/Home";
import Sign from "./pages/sign/Sign";
import Login from "./pages/login/Login";
import About from "./pages/about/About";
import OneCard from "./pages/oneCard/OneCard";
import { getToken } from "./pages/services/Token";
import Cart from "./pages/cart/Cart";

import { ToastContainer, toast } from "react-toastify";
import Wishlist from "./pages/wishlist/Wishlist";
import Contact from "./pages/contact/Contact";

function App() {
  // Bu AddCart bosilganda cartning sonini yangilash uchun
  const [cartNumber, setcartNumber] = useState(false);

  // Bu AddCart bosilganda modalni ochish uchun
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState(null);

  // Bu getData APIdagi hamma productlarni olish uchun
  const [data, setData] = useState(null);
  

  const [loader, setLoader] = useState(true);

  const getData = () => {
    if(getToken()){
      const myHeaders = new Headers();
    myHeaders.append("Authorization", `Bearer ${getToken()}`);

    const requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow",
    };

    fetch(
      "https://ecommercev01.pythonanywhere.com/product/list/",
      requestOptions
    )
      .then((response) => response.json())
      .then((result) => {
        setData(result)
        setLoader(false)
      })
      .catch((error) => console.error(error));
    }else{
      // const myHeaders = new Headers();
    // myHeaders.append("Authorization", `Bearer ${getToken()}`);

    const requestOptions = {
      method: "GET",
      // headers: myHeaders,
      redirect: "follow",
    };

    fetch(
      "https://ecommercev01.pythonanywhere.com/product/list/",
      requestOptions
    )
      .then((response) => response.json())
      .then((result) => {
        setData(result)
        setLoader(false)
      })
      .catch((error) => console.error(error));
    }
  };

  useEffect(() => {
    getData();
  }, []);

  // Bu getUser authorizationdan ro'yhatdan o'tganda user icon chiqishi uchun
  const [user, setUser] = useState(null);

  const getUser = () => {
    const myHeaders = new Headers();
    myHeaders.append("Authorization", `Bearer ${getToken()}`);

    const requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow",
    };

    fetch(
      "https://ecommercev01.pythonanywhere.com/user/detail/",
      requestOptions
    )
      .then((response) => response.json())
      .then((result) => {
        setUser(result);
      })
      .catch((error) => console.error(error));
  };

  useEffect(() => {
    getUser();
  }, [getToken()]);

  // Bu CartItems Korzinkadagi barcha tanlangan productlarni olish uchun
  const [items, setItems] = useState(null);
  const [Cartloader, setCartLoader] = useState(true);

  const CartItems = () => {
    const myHeaders = new Headers();
    myHeaders.append("Authorization", `Bearer ${getToken()}`);

    const requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow",
    };

    fetch(
      "https://ecommercev01.pythonanywhere.com/order/cart-items/",
      requestOptions
    )
      .then((response) => response.json())
      .then((result) => {
        setItems(result);
        setCartLoader(false);
      })
      .catch((error) => console.error(error));
  };

  useEffect(() => {
    CartItems();
  }, []);

  // Bu funksiya yurakcha osilganda Wishlistga productni qo'shadi
  const [isLiked, setIsLiked] = useState(null);

  const AddWishlist = (id) => {
    const myHeaders = new Headers();
    myHeaders.append("Authorization", `Bearer ${getToken()}`);

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      redirect: "follow",
    };

    fetch(
      `https://ecommercev01.pythonanywhere.com/action/add-to-wishlist/?product_id=${id}`,
      requestOptions
    )
      .then((response) => response.json())
      .then((result) => {
        setIsLiked(result);
        getData()
      })
      .catch((error) => console.error(error));
  };

  // Bu funksiya productni wishlistdan o'chiradi
  const [deleteInfo, setDeleteInfo] = useState(null)

  const deleteProductWishlist = (id) => {
    const myHeaders = new Headers();
myHeaders.append("Authorization", `Bearer ${getToken()}`);

const requestOptions = {
  method: "DELETE",
  headers: myHeaders,
  redirect: "follow"
};

fetch(`https://ecommercev01.pythonanywhere.com/action/remove-from-wishlist/?product_id=${id}`, requestOptions)
  .then((response) => response.json())
  .then((result) => {
    setDeleteInfo(result)
  })
  .catch((error) => console.error(error));
  };


     const [wishListNumber, setWishlistNumber] = useState(null)

     const getWishlist = () => {
        const myHeaders = new Headers();
        myHeaders.append("Authorization", `Bearer ${getToken()}`);
    
        const requestOptions = {
          method: "GET",
          headers: myHeaders,
          redirect: "follow",
        };
    
        fetch(
          "https://ecommercev01.pythonanywhere.com/action/my-wishlist/",
          requestOptions
        )
          .then((response) => response.json())
          .then((result) => {
            setWishlistNumber(result);
          })
          .catch((error) => console.error(error));
      };
  
  return (
    <div className="app">
      <BrowserRouter>
        <ToastContainer />
        <Navbar user={user} getUser={getUser} cartNumber={cartNumber} wishListNumber={wishListNumber} getData={getData}/>
        <Routes>
          <Route
            path="/"
            element={
              <Home
                data={data}
                loader={loader}
                modalOpen={modalOpen}
                setModalOpen={setModalOpen}
                selectedProductId={selectedProductId}
                setSelectedProductId={setSelectedProductId}
                setcartNumber={setcartNumber}
                AddWishlist={AddWishlist}
                isLiked={isLiked}
                deleteProductWishlist={deleteProductWishlist}
                deleteInfo={deleteInfo}
                getWishlist={getWishlist}
              />
            }
          />
          <Route path="/Sign" element={<Sign getUser={getUser} />} />
          <Route path="/login" element={<Login getUser={getUser} />} />
          <Route path="/about" element={<About />} />
          <Route path="/oneCard/:id" element={<OneCard data={data} cartNumber={cartNumber} setcartNumber={setcartNumber} getWishlist={getWishlist} isLiked={isLiked} deleteInfo={deleteInfo} AddWishlist={AddWishlist} deleteProductWishlist={deleteProductWishlist}/>} />
          <Route
            path="/cart"
            element={<Cart Cartloader={Cartloader} items={items} />}
          />
          <Route path="/wishlist" element={<Wishlist getData={getData}/>} />
          <Route path="/contact" element={<Contact/>}/>
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
