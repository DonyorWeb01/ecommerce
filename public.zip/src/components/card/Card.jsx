import React, { useState } from "react";
import "./Card.scss";
import { FaHeart, FaRegHeart } from "react-icons/fa6";
import { IoCartOutline } from "react-icons/io5";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { getToken } from "../../pages/services/Token";
import OneCard from "../../pages/oneCard/OneCard";

function Card({
  item,
  setModalOpen,
  setSelectedProductId,
  AddWishlist,
  isLiked,
  deleteProductWishlist,
  deleteInfo,
  getWishlist,
}) {
  const navigate = useNavigate();
  

  return (
    <div className="card">
      {/* <OneCard
        deleteProductWishlist={deleteProductWishlist}
        item={item}
        AddWishlist={AddWishlist}
        deleteInfo={deleteInfo}
      /> */}
      <div className="discount">-35%</div>
      <button
        onClick={() => {
          if (getToken()) {
            getWishlist();
            if (item?.is_liked == false) {
              AddWishlist(item?.id);
              toast.success(isLiked?.message);
            } else {
              deleteProductWishlist(item?.id);
              toast(deleteInfo?.message);
            }
          } else {
            navigate("/Sign");
            toast.info("Avval ro'yxatdan o'tishingiz kerak!");
          }
        }}
        className="like"
      >
        {item?.is_liked ? <FaHeart /> : <FaRegHeart />}
      </button>
      <Link to={`/oneCard/${item?.id}`}>
        <img
          src={`https://ecommercev01.pythonanywhere.com/${item.pictures[0]}`}
          alt="Product image not found"
          onError={(e) => (e.target.src = "fallback-image-url.jpg")}
        />
      </Link>
      <button
        onClick={() => {
          // modal(true)
          setSelectedProductId(item?.id);
          setModalOpen(true);
        }}
        className="add"
      >
        <IoCartOutline />
        <p>Add To Cart</p>
      </button>
      <p className="name">{item?.title}</p>
      <div className="price">
        <p>
          {" "}
          {item?.price} <span>{item?.discount_price}</span>
        </p>
      </div>
    </div>
  );
}

export default Card;
