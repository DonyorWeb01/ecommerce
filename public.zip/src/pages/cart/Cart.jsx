import React, { useEffect, useState } from 'react'
import './Cart.scss'
import { Link } from 'react-router-dom'
import { IoIosArrowDown } from 'react-icons/io'
import { FaTrashAlt } from 'react-icons/fa'
import { getToken } from '../services/Token'
import { FaPen } from 'react-icons/fa6'
import AddCartModal from '../../components/addCart/AddCartModal'

function Cart({Cartloader, items}) {
    console.log(items);
    

    const [counter, setCounter] = useState(1)


    return (
        <div className='cart'>
            <div className="container">
                <p><Link to={'/'}>Home</Link> / Cart</p>
                <div className="cart-main">
                    <ul>
                        <li>
                            <p>Product</p>
                            <p>Price</p>
                            <p>Quantity</p>
                            <p>Subtotal</p>
                            <p>Delete</p>
                        </li>
                        {
                            Cartloader && <div className="loader"><img src="../public/images/loader.gif" alt="" /></div>
                        }
                        {
                          getToken() ?  items?.cart_items.map((product)=>{
                                return <li>
                                <div className="product">
                                    <div className="img">
                                        <img src={`https://ecommercev01.pythonanywhere.com/${product?.pictures?.[0]?.file}`} alt="" />
                                    </div>
                                    <p>{product.title}</p>
                                </div>
                                <p className="price">{product.price}</p>
                                <div className="count">
                                    <div className="counter">
                                        <h2>{counter}</h2>
                                        <div className="btns">
                                            <button onClick={() => {
                                                setCounter(counter + 1)
                                            }} className='top'><IoIosArrowDown /></button>
                                            <button onClick={() => {
                                                if (counter > 1) {
                                                    setCounter(counter - 1)
                                                } else {
                                                    setCounter(1)
                                                }
                                            }} className='end'><IoIosArrowDown /></button>
                                        </div>
                                    </div>
                                </div>
                                <div className="subtotal">
                                    <p>{product.subtotal}</p>
                                </div>
                                <div className="buttons">
                                <button onClick={()=>{
                                    console.log(product.id);
                                    }} className='delete'><FaPen /></button>
                                <button className='delete'><FaTrashAlt /></button>
                                </div>
                            </li>
                            }) : <h1 className='error1'><h2>Sizda hali mahsulotlar yo'q!</h2></h1>

                        }
                    </ul>
                    <div className="btns1">
                        <button>Return To Shop</button>
                        <button>Update Cart</button>
                    </div>
                </div>
                <div className="subtotal-info">
                    <form action="">
                        <input type="text" placeholder='Coupon Code' />
                        <button>Apply Coupon</button>
                    </form>
                    <div className="cart-total">
                        <h1>Cart Total</h1>
                        <div className="text">
                            <p>Subtotal:</p>
                            <p>175$</p>
                        </div>
                        <div className="line"></div>
                        <div className="text">
                            <p>Subtotal:</p>
                            <p>175$</p>
                        </div>
                        <div className="line"></div>
                        <div style={{ marginBottom: "16px" }} className="text">
                            <p>Subtotal:</p>
                            <p>175$</p>
                        </div>
                        <button>Procees to checkout</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Cart
